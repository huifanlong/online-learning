# Pycharm目录结构

Created: March 20, 2022
Created by: Anonymous
Tags: python

![Untitled](Pycharm%E7%9B%AE%E5%BD%95%E7%BB%93%20fd770/Untitled.png)

![Untitled](Pycharm%E7%9B%AE%E5%BD%95%E7%BB%93%20fd770/Untitled%201.png)

一个项目下，可以有多种类型的根文件夹，以及普通文件夹。设置成特别类型的文件夹需要特别指定，每种特别类型的文件夹都有其特定颜色，如图所是。